from distutils.core import setup

setup(name='Lecipe',
      version='1.0',
      py_modules=['module1','mysmtplib','PythonApplication1']
      )
